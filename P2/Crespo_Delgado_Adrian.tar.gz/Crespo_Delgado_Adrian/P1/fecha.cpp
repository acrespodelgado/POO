#include "fecha.hpp"
#include <ctime>
#include <cstdio>
#include <clocale>

//Otra forma de definir la constante
//const int Fecha::AnnoMaximo(2037);

//Constructor por defecto
Fecha::Fecha(int d, int m, int a) : dia_{d}, mes_{m}, anno_{a}
{
	rectificarFecha();
	
	//Si no es v�lida una vez rectificada...
	if(!fechaValida(dia_, mes_, anno_))
    	throw Invalida("La fecha no es valida");
}

//Constructor de conversion
Fecha::Fecha(const char* cadena)
{
	//Conversion de cadena a fecha
	if(sscanf(cadena, "%d/%d/%d", &dia_, &mes_, &anno_) != 3)
        throw Invalida("El formato es invalido");
        
	rectificarFecha();
	
	//Si no es v�lida una vez rectificada...
	if(!fechaValida(dia_, mes_, anno_))
    	throw Invalida("La fecha no es valida");
}

//Comprueba si la fecha es Valida
bool Fecha::fechaValida(int d, int m, int a)
{
    bool valida = true, bisiesto = (a % 4 == 0 && (a % 400 == 0 || a % 100 != 0));

    if(!(m < 1 || m > 12))
    {
        switch(m)
        {
	        case 1: 
			case 3: 
			case 5:
	        case 7:
	        case 8:
	        case 10:
	        case 12:
	            if(d<1 || d>31) valida=false;
	            break;
	        case 4:
	        case 6:
	        case 9:
	        case 11:
	            if(d<1 || d>30) valida=false;
	            break;
	        case 2:
	            if((!bisiesto && (d<1 || d>28)) || (bisiesto && (d<1 || d>29))) valida=false;
	            break;
        }
        if(valida)
            if(a < AnnoMinimo || a > AnnoMaximo)
                valida =false;
    }
    else
        valida = false;
    return valida;
}

//Este m�todo se usa para poner la fecha del sistema si se le pasa un 0

void Fecha::rectificarFecha()
{
	//Tiempo descompuesto para la fecha del sistema
    std::time_t tiempo_calendario = std::time(0);
    std::tm* tiempo_descompuesto = std::localtime(&tiempo_calendario);

    if(dia_ == 0)
        dia_ = (int)tiempo_descompuesto->tm_mday;
    if(mes_ == 0)
        mes_ = (int)tiempo_descompuesto->tm_mon + 1;  
    if(anno_ == 0)
        anno_ = (int)tiempo_descompuesto->tm_year + 1900;
}

//Sobrecarga de operadores

Fecha &Fecha::operator += (int _dia)
{	
	dia_ += _dia;
	std::time_t tiempo_calendario = std::time(nullptr);
	std::tm *tiempo_descompuesto = std::localtime(&tiempo_calendario);
	tiempo_descompuesto->tm_hour = 12;
	tiempo_descompuesto->tm_mday = dia_;
	tiempo_descompuesto->tm_mon = mes_ - 1;
	tiempo_descompuesto->tm_year = anno_ - 1900;
	time_t nuevo_tiempo = mktime(tiempo_descompuesto);
	tm* tiempo_final = localtime(&nuevo_tiempo);
	
	//Asignamos a los atributos
	dia_ = tiempo_final->tm_mday;
	mes_ = tiempo_final->tm_mon + 1;
	anno_ = tiempo_final->tm_year + 1900;
	
	//Comprobamos que anno no est� fuera de rango
	if (anno_ > AnnoMaximo || anno_ < AnnoMinimo)
		throw Invalida("Anno fuera de rango");
	return *this;
}

//Para el resto de operadores usamos el operador +=
Fecha &Fecha::operator -= (int _dia)
{
	*this += -_dia;
	return *this;
}

Fecha &Fecha::operator ++ ()
{
	*this += 1;
	return *this;
}

Fecha &Fecha::operator -- ()
{
	*this += -1;
	return *this;
}

Fecha Fecha::operator ++ (int)
{
	//�mbito local de la funci�n
	Fecha copia(*this);
	*this += 1;
	return copia;
}

Fecha Fecha::operator -- (int)
{
	//�mbito local de la funci�n
	Fecha copia(*this);
	*this += -1;
	return copia;
}

Fecha Fecha::operator + (int _dia) const
{
	Fecha copia(*this);
	return copia += _dia;
}

Fecha Fecha::operator - (int _dia) const
{
	Fecha copia(*this);
	return copia += -_dia;
}

const char *Fecha::cadena() const noexcept
{
	static char fec[50];
	setlocale(LC_TIME, "");
	std::time_t tiempo_calendario = std::time(NULL);
	std::tm* tiempo_descompuesto = std::localtime(&tiempo_calendario);
	tiempo_descompuesto->tm_hour = 12;
	tiempo_descompuesto->tm_year = anno_ - 1900;
	tiempo_descompuesto->tm_mday = dia_;
	tiempo_descompuesto->tm_mon = mes_ - 1;
	time_t nuevo_tiempo = mktime(tiempo_descompuesto);
	tm* tiempo_final = localtime(&nuevo_tiempo);
	strftime(fec, 49, "%A %d de %B de %Y", tiempo_final);
	return fec;
}

//Para el resto de operadores usaremos < y == 
bool operator < (const Fecha &f1, const Fecha &f2) noexcept
{	
	bool menor = false;
	if(f1.anno() < f2.anno())
		menor = true;
	else if (f1.anno() == f2.anno() && f1.mes() < f2.mes())
		menor = true;
	else if(f1.anno() == f2.anno() && f1.mes() == f2.mes() &&  f1.dia() < f2.dia())
		menor = true;
	return menor;
}

bool operator == (const Fecha &f1, const Fecha &f2) noexcept
{	
	return f1.anno() == f2.anno() && f1.mes() == f2.mes() &&  f1.dia() == f2.dia();
}

bool operator > (const Fecha &f1, const Fecha &f2) noexcept
{
	return f2 < f1;
}

bool operator <= (const Fecha &f1, const Fecha &f2) noexcept
{
	return !(f2 < f1);
}

bool operator >= (const Fecha &f1, const Fecha &f2) noexcept
{
	return !(f1 < f2);
}

bool operator != (const Fecha &f1, const Fecha &f2) noexcept
{
	return !(f1 == f2);
}

//Operadores de flujo
std::istream &operator>>(std::istream &is, Fecha &f){
	char aux[11];
	is.getline(aux, 11);
	try{
		f = Fecha(aux);
	}catch(Fecha::Invalida &e){
		is.setstate(std::ios::failbit);
		throw;
	}
	return is;
}

std::ostream &operator<<(std::ostream &os, const Fecha &f) noexcept{
	os << f.cadena();
	return os;
}
