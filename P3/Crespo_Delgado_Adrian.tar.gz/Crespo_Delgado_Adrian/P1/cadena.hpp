#ifndef CADENA_HPP
#define CADENA_HPP
#include <cstring>
#include <iostream>
#include <iterator>
#include<string>

class Cadena
{
	public:
		//Constructor por defecto
		explicit Cadena(unsigned t = 0, char c = ' ') noexcept;
		//Constructor de copia
		Cadena(const Cadena &otraCadena) noexcept;
		//Constructor a partir de cadena de bajo nivel
		Cadena(const char *otraCadena) noexcept;
		//Constructor de copia con mov
		Cadena(Cadena &&otraCadena) noexcept;
		//Operador con sem�ntica de movimiento
		Cadena &operator = (Cadena &&otraCadena) noexcept;
		//Observador que devuelve longitud de la cadena
		inline unsigned length() const noexcept { return tam_; }
		//Funcion substr para las subcadenas dada una posici�n y un tamanno
		Cadena substr(unsigned pos, unsigned tam) const;
		//Observador para devolver la cadena
		inline const char *c_str() const noexcept { return s_; }
		//Sobrecarga de operadores de asignacion
		Cadena &operator = (const Cadena &cad) noexcept;
		Cadena &operator = (const char *cad) noexcept;
		Cadena &operator += (const Cadena &cad) noexcept;
		//Sobrecarga del operador []
		inline char operator[] (unsigned pos) const noexcept { return *(s_ + pos); }
		inline char &operator[] (unsigned pos) noexcept { return *(s_ + pos); }
		//Funcion at similar a []
		char at(unsigned pos) const;
		char &at(unsigned pos);
		inline ~Cadena() { delete[] s_; } 
		//Iteradores
		typedef char* iterator;
		typedef char const* const_iterator;
		typedef std::reverse_iterator<iterator> reverse_iterator;
		typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
		inline iterator begin() noexcept { return s_; }
		inline const_iterator begin() const noexcept { return s_; }
		inline iterator end() noexcept { return s_ + tam_; }
		inline const_iterator end() const noexcept { return s_ + tam_; }
		inline reverse_iterator rbegin() noexcept { return reverse_iterator(end()); }
		inline const_reverse_iterator rbegin() const noexcept { return const_reverse_iterator(end()); }
		inline reverse_iterator rend() noexcept { return reverse_iterator(begin()); }
		inline const_reverse_iterator rend() const noexcept { return const_reverse_iterator(begin()); }
		inline const_iterator cbegin() const noexcept { return s_; }
		inline const_iterator cend() const noexcept { return s_ + tam_; }
		inline const_reverse_iterator crbegin() const noexcept { return const_reverse_iterator(end()); }
		inline const_reverse_iterator crend() const noexcept { return const_reverse_iterator(begin()); }
	private:
		//Atributo cadena y tamanno de la cadena
		unsigned tam_;
		char *s_;
};

//Sobrecarga de operadores binarios
Cadena operator + (const Cadena &cad1, const Cadena &cad2) noexcept;
//Sobrecarga de operadores comparadores
bool operator == (const Cadena &cad1, const Cadena &cad2) noexcept;
bool operator != (const Cadena &cad1, const Cadena &cad2) noexcept;
bool operator  < (const Cadena &cad1, const Cadena &cad2) noexcept;
bool operator  > (const Cadena &cad1, const Cadena &cad2) noexcept;
bool operator  <= (const Cadena &cad1, const Cadena &cad2) noexcept;
bool operator  >= (const Cadena &cad1, const Cadena &cad2) noexcept;

//Flujo
std::ostream &operator<<(std::ostream&, const Cadena&) noexcept;
std::istream &operator>>(std::istream&, Cadena&) noexcept;


// Para P2 y ss. 
// Especializaci�n de la plantilla hash<T>para de?nir la
// funci�n hash a utilizar con contenedores desordenados de 
// Cadena, unordered_[set|map|multiset|multimap].

namespace std { 
// Estaremos dentro del espacio de nombres std 
	template <> // Es una especializaci�n de una plantilla para Cadena 
	struct hash<Cadena> { // Es una clase con solo un operador publico 
		size_t operator() (const Cadena& cad) const // El operador funci�n 
		{ 
			hash<string> hs; // Creamos un objeto hash de string 
			const char* p = cad.c_str(); // Obtenemos la cadena de la Cadena 
			string s(p); // Creamos un string desde una cadena 
			size_t res = hs(s); // El hash del string. Como hs.operator()(s); 
			return res;
		}
	};
}

#endif
