#include "cadena.hpp"
#include <stdexcept>
#include <cctype>

//En los constructores inicializamos los parametros de tama�o de la cadena

//Constructor con parametros por defecto
Cadena::Cadena(unsigned t, char c) noexcept : tam_{t}, s_{new char[t+1]}
{
	for(int i = 0; i < t; ++i)
	{
		//A�adimos los caracteres uno a uno
		s_[i] = c;
	}
	//Y en la ultima posicion el caracter terminador
	s_[t] = '\0';
}

//Constructor de copia de otra cadena
Cadena::Cadena(const Cadena &otraCadena) noexcept : tam_{otraCadena.tam_}, s_{new char[otraCadena.tam_ + 1]}
{
	//Funcion de copia de string
	//Destino el atributo s_ del nuevo objeto, origen el parametro s_ de la cadena que se copia.
	strcpy(s_, otraCadena.s_);
}

//Constructor de copia a trav�s de una cadena de caracteres de bajo nivel
//Como es una cadena de bajo nivel podemos usar la funcion strlen de string
Cadena::Cadena(const char *otraCadena) noexcept : tam_{(unsigned)strlen(otraCadena)}, s_{new char[strlen(otraCadena) + 1]}
{
	strcpy(s_, otraCadena);
}

//Constructor con sem�ntica de movimiento
Cadena::Cadena(Cadena &&cad) noexcept : tam_{cad.tam_}, s_{cad.s_} {
	cad.s_ = nullptr;
	cad.tam_ = 0;
}

//Funcion at similar al corchete []
char Cadena::at(unsigned pos) const
{
	//Igual que el [] pero lanza excepcion si se sale de rango
	if(pos >= tam_)
		throw std::out_of_range("Fuera de rango");
	return *(s_ + pos);
}

char &Cadena::at(unsigned pos)
{
	//Igual que el [] pero lanza excepcion si se sale de rango
	if(pos >= tam_)
		throw std::out_of_range("Fuera de rango");
	return *(s_ + pos);
}

//Sobrecarga de operadores de asignacion
Cadena &Cadena::operator = (const Cadena &cad) noexcept
{
	if(this != &cad)
	{
		if(tam_ != cad.tam_)
		{
			tam_ = cad.tam_;
			//Como una cadena es mas larga que otra hay que crearla de nuevo, borramos y creamos con +1 para el caracter terminador
			delete[] s_;
			s_ = new char[tam_ + 1];
		}
		strcpy(s_, cad.s_);
	}
	return *this;
}

Cadena &Cadena::operator = (const char *cad) noexcept
{
	unsigned tamAuxiliar = strlen(cad);
	if(tam_ != tamAuxiliar)
	{
		tam_ = tamAuxiliar;	
		//Como eran de distinto tama�o hay que borrar
		delete[] s_;
		s_ = new char[tam_ + 1];
	}
	strcpy(s_, cad);
	return *this;
}

//Sobrecarga de operador de movimiento
Cadena &Cadena::operator = (Cadena &&cad) noexcept{
	if(this != &cad){
		delete[] s_;
		s_ = cad.s_;
		tam_ = cad.tam_;
		cad.s_ = nullptr;
		cad.tam_ = 0;
	}
	return *this;
}

//Sobrecarga de operadores
Cadena &Cadena::operator += (const Cadena &cad) noexcept
{
	//Creamos una cadena auxiliar para no modificar la cadena anterior y le guardamos un hueco para el caracter terminador
	char* aux = new char[tam_ + 1];
	//Copiamos el contenido de la cadena a la auxiliar
	strcpy(aux, s_);
	//Borro el contenido de s_, porque ya pasa a ser otro
	delete[] s_;
	//Creo el nuevo contenido de s con el tama�o de la anterior cadena y la nueva, +1 para el caracter terminador
	tam_ += cad.tam_;
	s_ = new char[tam_ + 1];
	//Ahora copio a s_ el contenido que tenia anteriormente
	strcpy(s_, aux);
	//Y le concateno la otra cadena con la funcion de string
	strcat(s_, cad.s_);
	delete[] aux;
	return *this;
}

//Funcion substr para la subcadena
Cadena Cadena::substr(unsigned pos, unsigned tam) const
{
	//Para ver si se sale de rango...
	if(pos + tam >= tam_ || tam_ - tam < tam)
		throw std::out_of_range("Fuera de rango");
	//Creamos el vector de caracteres
	Cadena aux(tam + 1);
	//Recorremos caracter a caracter desde el substring
	for(int i = pos; i < (pos + tam); ++i)
	{
		aux.s_[i - pos] = s_[i];
	}
	//En la ultima posicion le a�adimos el caracter terminador
	aux.s_[tam] = '\0';
	return aux;
}

//Para este operador usamos el creado anteriormente
Cadena operator + (const Cadena &cad1, const Cadena &cad2) noexcept
{
	//Como no se tiene que modificar cad1, hacemos una auxiliar
	Cadena aux(cad1);
	aux += cad2;
	return aux;
}

//Para este operador usamos la funcion de string strcmp
bool operator == (const Cadena &cad1, const Cadena &cad2) noexcept
{
	return strcmp(cad1.c_str(), cad2.c_str()) == 0;
}

bool operator != (const Cadena &cad1, const Cadena &cad2) noexcept
{
	return !(cad1 == cad2);
}

bool operator < (const Cadena &cad1, const Cadena &cad2) noexcept
{
	//Si devuelve -1 es menor
	return strcmp(cad1.c_str(), cad2.c_str()) < 0;
}

bool operator > (const Cadena &cad1, const Cadena &cad2) noexcept
{
	//Si devuelve -1 es menor
	return cad2 < cad1;
}

bool operator <= (const Cadena &cad1, const Cadena &cad2) noexcept
{
	//Si devuelve -1 es menor
	return !(cad2 < cad1);
}

bool operator >= (const Cadena &cad1, const Cadena &cad2) noexcept
{
	//Si devuelve -1 es menor
	return !(cad1 < cad2);
}

//Operador de extraccion
std::istream &operator>>(std::istream &is, Cadena &cad) noexcept{
	char aux[33];
	unsigned i = 0;
	while(isspace(is.get()) && is.good());
	is.unget();
	while(i < 32 && !isspace(is.peek()) && is.good()){
		char c = is.get();
		if(is.good())
			aux[i++] = c;
	}
	aux[i] = '\0';
	cad = aux;
	return is;
}

std::ostream &operator<<(std::ostream &os, const Cadena &cad) noexcept{
	return os << cad.c_str();
}
