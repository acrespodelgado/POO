#ifndef FECHA_HPP_
#define FECHA_HPP_
#include <iostream>

class Fecha
{
    public:
        //Clase de excepcion Fecha::Invalida
        class Invalida
        {
        	//Definimos el constructor y el metodo que devuelve el motivo
            public:
            	//Recibe una cadena y devuelve otra cadena con el motivo
            	inline Invalida(const char *cadena) : motivo(cadena) {}
                inline const char* por_que() const { return motivo; }
            private:
            	//Definimos la variable que guarda el motivo del fallo
            	const char *motivo;
        };

        //Constructor con parametros por defecto
        //explicit para evitar conversion implicita
        explicit Fecha(int d = 0, int m = 0, int a = 0);

        //Constructor por caracteres
        Fecha(const char* cadena);
    
        //Constructor de copia no es necesario
        Fecha(const Fecha& f) = default;
        
        //M�todo expl�cito de conversi�n
        
        
        //M�todo para asignarle la fecha del sistema si vienen 0
        void rectificarFecha();

        //Constantes
        static const int AnnoMinimo = 1902;
        static const int AnnoMaximo = 2037;
        
        //Sobrecarga de operadores
        
        //Asignacion con incremento/de
		Fecha &operator += (int _dia);
		Fecha &operator -= (int _dia);
		//Preincremento
		Fecha &operator ++ ();
		Fecha &operator -- ();
		//Postincremento
		Fecha operator ++ (int);
		Fecha operator -- (int);
		//Operadores binarios
		Fecha operator + (int _dia) const;
		Fecha operator - (int _dia) const;
		//Operador asignacion
		Fecha &operator = (const Fecha &f) = default;
		//Conversion implicita a cadena
		const char * cadena() const noexcept;
		
		//M�todos observadores
		inline int dia() const noexcept { return dia_; }
		inline int mes() const noexcept { return mes_; }
		inline int anno() const noexcept { return anno_; }
		
    private:
        static bool fechaValida(int, int, int);
        int dia_, mes_, anno_;
};

//Operadores de flujo cin cout
std::istream &operator>>(std::istream &is, Fecha &f);
std::ostream &operator<<(std::ostream &os, const Fecha &f) noexcept;

//Operadores de comparacion
bool operator < (const Fecha &f1, const Fecha &f2) noexcept;
bool operator == (const Fecha &f1, const Fecha &f2) noexcept;
bool operator > (const Fecha &f1, const Fecha &f2) noexcept;
bool operator <= (const Fecha &f1, const Fecha &f2) noexcept;
bool operator >= (const Fecha &f1, const Fecha &f2) noexcept;
bool operator != (const Fecha &f1, const Fecha &f2) noexcept;

#endif //FECHA_HPP_
